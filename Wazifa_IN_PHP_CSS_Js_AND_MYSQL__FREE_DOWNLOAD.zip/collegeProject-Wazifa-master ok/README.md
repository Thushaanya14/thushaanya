Software Name as Headline
======
**Wazifa** Wazifa is a social media network for workers and job seekers where people can add or follow each other
users can add posts, like, comment, share, communicate, etc..

## Download
* [Version 1.0](https://github.com/xmansyx/collegeProject-Wazifa/archive/master.zip)


## Usage
downlaod > move to your server > add sql to your database > ready to go
...
