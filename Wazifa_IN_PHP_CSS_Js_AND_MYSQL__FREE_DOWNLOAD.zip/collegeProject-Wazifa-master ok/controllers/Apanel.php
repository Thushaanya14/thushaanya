<?php



if(isset( $_post['submit'] )){

EventTable($array);


	}
?>